import numpy as np
arr1 = np.arange(0,100,step=5)
arr2=np.arange(0,20)
arr3=np.arange(300,400,step=5)
print(arr1)
print(arr2)
print(arr3)
