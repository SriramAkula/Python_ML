import numpy as np
x=np.array([[1],[2],[7]])
#print(x.shape)
#print(f'A 3-D Vector:\n{x}')
a=np.array([[1],[2],[3]])
b=np.array([[23],[9],[8]])
c=np.add(b,a)
#print("Sum of two matrices: \n",a+b)
print("Sum of two matrices: \n",c)