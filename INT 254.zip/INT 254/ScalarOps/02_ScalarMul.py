import numpy as np
x=np.array([[1],[2],[3]])
y=np.array([[10],[20],[13]])
print(np.multiply(y,x))
#print(x*y)
print(7*y)