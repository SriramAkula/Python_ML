import numpy as np
x=np.array([[1],[3]])
y=np.array([[5],[9]])
a,b=2,4
c=a*x+b*y
print(c)