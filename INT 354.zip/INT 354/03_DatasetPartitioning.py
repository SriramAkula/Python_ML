import pandas as pd
data=pd.read_csv('Iris.csv')
# print(data.head())
print(data)