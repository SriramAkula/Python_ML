print(df.fillna(df.mean()))
